function [QQQR,QQQR_zz] = TSPLJ0613_np(X,Y,node,keynodeID,keynode,LBnode)
t = 1;
for i=1:length(LBnode)
    LBjuzhen(t,1) = LBnode(i).IDi;
    LBjuzhen(t,2) = LBnode(i).IDj;
    t = t+1;
end 
N=size(keynode,1);                      
distance=zeros(N,N);           
for i=1:N
    for j=1:N
        distance(i,j) = sqrt(sum((keynode(i,:)-keynode(j,:)).^2));
    end
end
m = ceil(length(keynode)*1.5);  
NC_max = 200;                  
Alpha = 1;                     
Beta = 5;                   
Rho =0.25;                     
Q = 100;                        
Eta = 1./distance;              
XXS = ones(N,N);               
LJtable = zeros(m,N);          
gen = 1;                        
R_best = zeros(NC_max,N);         
L_best = inf.*ones(NC_max,1);     
QQQQ = [];  
QQQL = [];  
QQQB = [];  
QQQXJ = []; 
while gen <= NC_max
    start = [];
    for i=1:(ceil(m/N))                            
        start = [start,randperm(N)];      
    end
    LJtable(:,1) = (start(1,1:m))';            
    for i=2:N 
        for j=1:m 
            visited = LJtable(j,1:(i-1));   
            unvisited = zeros(1,(N+1-i));   
            visit_P = unvisited;           
            count = 1;
            for k=1:N   
                if isempty(find( visited == k)) 
                    unvisited(count) = k;
                    count = count+1;
                end
            end
            for k=1:length(unvisited)  
                visit_P(k) = ((XXS(visited(end),unvisited(k)))^Alpha) * ( Eta(visited(end),unvisited(k))^Beta );   
            end             
            visit_P = visit_P/sum(visit_P);                
            Pcum = cumsum(visit_P);
            selected = find(Pcum>=rand);
            to_visited = unvisited(selected(1));    
            LJtable(j,i) = to_visited;              
        end
    end     
    if gen>=2
        LJtable(1,:) = R_best(gen-1,:); 
    end     
    L = zeros(1,m); 
    B = zeros(1,m);  
    for i=1:m
        Route = LJtable(i,:);      
        L(i) = distance(Route(N),Route(1)); 
        for j=1:(N-1)
            L(i) = L(i)+distance(Route(j),Route(j+1));  
        end
        B(i) = LBnum_Calculate0615 (node,Route,keynodeID,LBjuzhen,LBnode); 
    end
    XJ = B ./ L;  
    F_rank =   FPX5(L,XJ)';  % 得到各个蚂蚁的前沿等级
        t=1;
        for i = 1:length(F_rank)
            if F_rank(i)==1
                F1(t) = i;
                t=t+1;
            end
        end
        for i =1:length(F1)
            QQQQ = [QQQQ;LJtable(F1(i),:)]; 
            QQQL = [QQQL;L(F1(i))];         
            QQQXJ = [QQQXJ;XJ(F1(i))];
        end
    ccc = Q./L;
    pingjia = 10*0.3*XJ + ccc; 
    pos = find(pingjia == max(pingjia));   
    R_best(gen,:) = LJtable(pos(1),:);
    L_jilu(gen) =  L(pos(1));
    LBnum_jilu(gen) = B(pos(1));
    Delta_XXS = zeros(N,N);     
    for i=1:m           
        if F_rank(i)==1
            for j=1:(N-1)                                                                          
                Delta_XXS(LJtable(i,j),LJtable(i,j+1)) = Delta_XXS(LJtable(i,j),LJtable(i,j+1)) + 3*( Q/L(i) + XJ(i) ); 
            end
            Delta_XXS(LJtable(i,N),LJtable(i,1)) = Delta_XXS(LJtable(i,N),LJtable(i,1)) + 3*( Q/L(i) + XJ(i) );     
        end     
        if F_rank(i)==2
            for j=1:(N-1)   
                Delta_XXS(LJtable(i,j),LJtable(i,j+1)) = Delta_XXS(LJtable(i,j),LJtable(i,j+1)) + 1*( Q/L(i) + XJ(i) ); 
            end
            Delta_XXS(LJtable(i,N),LJtable(i,1)) = Delta_XXS(LJtable(i,N),LJtable(i,1)) + 1*( Q/L(i) + XJ(i) );    
        end
        
        if F_rank(i)~=1 && F_rank(i)~=2
            for j=1:(N-1)  
                Delta_XXS(LJtable(i,j),LJtable(i,j+1)) = Delta_XXS(LJtable(i,j),LJtable(i,j+1)) + 0 *( Q/L(i) + XJ(i) ); 
            end
            Delta_XXS(LJtable(i,N),LJtable(i,1)) = Delta_XXS(LJtable(i,N),LJtable(i,1)) + 0*( Q/L(i) + XJ(i) );    
        end
    end
    XXS = (1-Rho).*XXS + Delta_XXS;    
    gen = gen + 1;
    LJtable = zeros(m,N); 
end

F_rank2 =  FPX5(QQQL,QQQXJ)';    
QQQR = [];                        
QQQR_L = [];
QQQR_XJ = [];
for i = 1:length(F_rank2)
    if F_rank2(i) == 1
        QQQR = [QQQR;QQQQ(i,:)];
        QQQR_L = [QQQR_L;QQQL(i,:)];
        QQQR_XJ = [QQQR_XJ;QQQXJ(i,:)];
    end
end
zuiduanxuhao = find(min(QQQR_L) == QQQR_L);
QQQR_zz = QQQR(zuiduanxuhao,:);                  
% zuidaxuhao = find(max(QQQR_XJ) == QQQR_XJ);
% QQQR_zz = QQQR(zuidaxuhao,:);                     




