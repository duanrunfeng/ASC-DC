function [QQQR,QQQR_zz] = TSPLJ0613(X,Y,node,keynodeID,keynode,LBnode)
t = 1;
for i=1:length(LBnode)
    LBjuzhen(t,1) = LBnode(i).IDi;
    LBjuzhen(t,2) = LBnode(i).IDj;
    t = t+1;
end 
N=size(keynode,1);                         
distance=zeros(N,N);            
for i=1:N
    for j=1:N
        distance(i,j) = sqrt(sum((keynode(i,:)-keynode(j,:)).^2));
    end
end
m = ceil(length(keynode)*1.5);  % 蚂蚁的个数
NC_max = 200;                   % 最大迭代次数
Alpha = 1;                      % 信息素的重要程度
Beta = 5;                       % 启发因子的重要程度
Rho =0.25;                      % 信息素蒸发系数
Q = 100;                        % 信息素增加强度系数
Eta = 1./distance;              % 启发式因子
XXS = ones(N,N);                % 信息素矩阵
LJtable = zeros(m,N);           % 禁忌表
gen = 1;                        % 迭代计数器
R_best = zeros(NC_max,N);         % 各代的最佳路线
L_best = inf.*ones(NC_max,1);     % 每一代的最佳路径的长度，初始假设为无穷大（inf正无穷）
QQQQ = [];  
QQQL = [];  
QQQB = [];  
QQQXJ = []; 

while gen <= NC_max
    
    start = [];
    for i=1:(ceil(m/N))                            
        start = [start,randperm(N)];  
    end
    LJtable(:,1) = (start(1,1:m))';     
    for i=2:N % 从第二个城市开始
        for j=1:m % 每只蚂蚁
            visited = LJtable(j,1:(i-1));    
            unvisited = zeros(1,(N+1-i));   
            visit_P = unvisited;            
            count = 1;
            for k=1:N   
                if isempty(find( visited == k))
                    unvisited(count) = k;
                    count = count+1;
                end
            end
            for k=1:length(unvisited)  
                visit_P(k) = ((XXS(visited(end),unvisited(k)))^Alpha) * ( Eta(visited(end),unvisited(k))^Beta );    
            end             
            visit_P = visit_P/sum(visit_P);                 
            Pcum = cumsum(visit_P);
            selected = find(Pcum>=rand);
            to_visited = unvisited(selected(1));    % 蚂蚁j选择出的城市编号
            LJtable(j,i) = to_visited;              % 添加到禁忌表
        end
    end     
    if gen>=2
        LJtable(1,:) = R_best(gen-1,:);
    end     
    %%% ****** 记录最佳路线
    L = zeros(1,m);  
    B = zeros(1,m);  
    for i=1:m
        Route = LJtable(i,:);       
        L(i) = distance(Route(N),Route(1));
        for j=1:(N-1)
            L(i) = L(i)+distance(Route(j),Route(j+1));  
        end
        B(i) = LBnum_Calculate0615 (node,Route,keynodeID,LBjuzhen,LBnode); 
    end
    XJ = B ./ L;
    
    %%  
    F_rank =   FPX5(L,XJ)';  % 得到各个蚂蚁的前沿等级

%      %%****** 前沿面绘图
%       set(gcf,'position',[360,55,720,720]);  % [左边距，下边距，图窗高，图窗宽] 
%       for i =1:length(L)
%           hold on
%           aaaa1 = scatter(L(i),0.1/XJ(i));
%           aaaa1.Marker = '.';
%           aaaa1.SizeData = 150;
%           text(L(i),0.1/XJ(i),num2str((i)),'FontSize',9,'HorizontalAlignment','center','VerticalAlignment','cap', 'Color','black')
%       end 
%       for i =1:length(F_rank)
%           if F_rank(i)==1
%               aaaa2 = scatter(L(i),0.1/XJ(i));
%               aaaa2.Marker = 'pentagram';
%               aaaa2.MarkerFaceColor = 'red';
%               aaaa2.MarkerEdgeColor = 'yellow';
%               aaaa2.SizeData = 150;
%           end
%       end
        t=1;
        for i = 1:length(F_rank)
            if F_rank(i)==1
                F1(t) = i;
                t=t+1;
            end
        end
        for i =1:length(F1)
            QQQQ = [QQQQ;LJtable(F1(i),:)];  
            QQQL = [QQQL;L(F1(i))];         
            QQQXJ = [QQQXJ;XJ(F1(i))];
        end
     
    %% %%% 用加权作输出
    ccc = Q./L;
    pingjia = 10*0.3*XJ + ccc;  
    pos = find(pingjia == max(pingjia));
    R_best(gen,:) = LJtable(pos(1),:);
    L_jilu(gen) =  L(pos(1));
    LBnum_jilu(gen) = B(pos(1));
    Delta_XXS = zeros(N,N);     
    for i=1:m           
        if F_rank(i)==1
            for j=1:(N-1)                                                                        
                Delta_XXS(LJtable(i,j),LJtable(i,j+1)) = Delta_XXS(LJtable(i,j),LJtable(i,j+1)) + 3*( Q/L(i) + XJ(i) );
            end
            Delta_XXS(LJtable(i,N),LJtable(i,1)) = Delta_XXS(LJtable(i,N),LJtable(i,1)) + 3*( Q/L(i) + XJ(i) ); 
        end     
        if F_rank(i)==2
            for j=1:(N-1)   
                Delta_XXS(LJtable(i,j),LJtable(i,j+1)) = Delta_XXS(LJtable(i,j),LJtable(i,j+1)) + 1*( Q/L(i) + XJ(i) );
            end
            Delta_XXS(LJtable(i,N),LJtable(i,1)) = Delta_XXS(LJtable(i,N),LJtable(i,1)) + 1*( Q/L(i) + XJ(i) );     
        end
        
        if F_rank(i)~=1 && F_rank(i)~=2
            for j=1:(N-1)   
                Delta_XXS(LJtable(i,j),LJtable(i,j+1)) = Delta_XXS(LJtable(i,j),LJtable(i,j+1)) + 0 *( Q/L(i) + XJ(i) );
            end
            Delta_XXS(LJtable(i,N),LJtable(i,1)) = Delta_XXS(LJtable(i,N),LJtable(i,1)) + 0*( Q/L(i) + XJ(i) );     
        end
    end
    XXS = (1-Rho).*XXS + Delta_XXS;     
    gen = gen + 1;
    LJtable = zeros(m,N); % 禁忌表清零
end

%% 
F_rank2 =  FPX5(QQQL,QQQXJ)';  
QQQR = [];                        
QQQR_L = [];
QQQR_XJ = [];
for i = 1:length(F_rank2)
    if F_rank2(i) == 1
        QQQR = [QQQR;QQQQ(i,:)];
        QQQR_L = [QQQR_L;QQQL(i,:)];
        QQQR_XJ = [QQQR_XJ;QQQXJ(i,:)];
    end
end

%%
figure
tiledlayout(3,6);  % tiledlayout(m,n),创建分块图布局m行列 
for g =1:length(QQQR(:,1))
    pause(0.001)
    %%% *** tiledlayout分块图
    nexttile                
    hold on
    box on  % 显示坐标区轮廓
    set( gca, 'XTick', [], 'YTick', [] );  % 不显示坐标轴刻度
    set(gcf,'position',[85,60,1400,720]);  % [左边距，下边距，图窗宽，图窗高]
    axis([-320 320 -320 320]);             % 显示范围。

    for i=1:(N-1)
        a1 = [keynode(QQQR(g,i),1),keynode(QQQR(g,i+1),1)];
        a2 = [keynode(QQQR(g,i),2),keynode(QQQR(g,i+1),2)];
        r1 = plot(a1,a2,'.r-.');      % 最优访问城市编号顺序
        r1.LineWidth = 0.75;
        r1.MarkerSize = 9;
    end
    a3 = [keynode(QQQR(g,N),1),keynode(QQQR(g,1),1)];
    a4 = [keynode(QQQR(g,N),2),keynode(QQQR(g,1),2)];
    r2 = plot(a3,a4,'.r-.'); % 最优访问城市编号顺序
    r2.LineWidth = 0.75;
    r2.MarkerSize = 9;
    z = title(['F1-R_',num2str(g)]);
    f = subtitle(['长度: ', num2str(QQQR_L(g)) ,'  XJ: ',num2str(100*QQQR_XJ(g))]);
    z.Color = 'b';
    z.FontWeight = 'bold';    % 加粗
    f.FontSize = 9.3;         % 字体大小
    z.FontName = 'Times New Roman';
    f.FontName = '新宋体'; 

end

%% 
zuiduanxuhao = find(min(QQQR_L) == QQQR_L);
QQQR_zz = QQQR(zuiduanxuhao,:);
% zuidaxuhao = find(max(QQQR_XJ) == QQQR_XJ);
% QQQR_zz = QQQR(zuidaxuhao,:);




