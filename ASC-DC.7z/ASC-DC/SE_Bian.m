%% 输入边的起点和终点，找出该边的邻边节点
function [shuchu,shuchu_ID] =SE_Bian(Start,End)      
LBnode = evalin('base', 'LBnode');
node = evalin('base', 'node');
t = 1;
for i=1:length(LBnode)
    LBjuzhen(t,1) = LBnode(i).IDi;
    LBjuzhen(t,2) = LBnode(i).IDj;
    t = t+1;
end
xuhao = find( LBjuzhen(:,1) == Start &  LBjuzhen(:,2) == End   ) ;
AAA = LBnode(xuhao).LBnodeID ; 
if Start ~= 0
    Bian162_198(1,1) = node(Start).x;
    Bian162_198(1,2) = node(Start).y;
    Bian162_198(1,3) = node(Start).ID;
else
    Bian162_198(1,1) = 0;
    Bian162_198(1,2) = 0;
    Bian162_198(1,3) = 0;
end
t = 2;
for i = 1:length(AAA)
    Bian162_198(t,1) = node(AAA(i)).x;
    Bian162_198(t,2) = node(AAA(i)).y;
    Bian162_198(t,3) = node(AAA(i)).ID;
    t= t+1;
end
if End ~= 0
    Bian162_198(t,1) = node(End).x;
    Bian162_198(t,2) = node(End).y;   % Bian的第一行为起点节点坐标，最后一行为终点节点坐标
    Bian162_198(t,3) = node(End).ID;
else
    Bian162_198(t,1) = 0;
    Bian162_198(t,2) = 0;
    Bian162_198(t,3) = 0;
end
shuchu_ID = Bian162_198; % 第三列是对应的ID
Bian162_198(:,3) = [];
shuchu = Bian162_198;
end
