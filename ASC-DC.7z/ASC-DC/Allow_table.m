function [H] = Allow_table(Bian)     

end_point = length(Bian); 
for i=1:length(Bian)
    for j=1:length(Bian)
        distance(i,j) = sqrt(sum((Bian(i,:)-Bian(j,:)).^2));
    end
end
H = distance;

y2 = Bian(length(Bian),2) ;
y1 = Bian(1,2);
x1 = Bian(1,1);
x2 = Bian(length(Bian),1);

a = y2-y1;
b = x1-x2;
c = x2*y1-x1*y2;

for i = 1:length(Bian)
    chuizu(i,1) = (b*b * Bian(i,1) -a*b * Bian(i,2) - a*c)/(a*a+b*b);
    chuizu(i,2) = (a*a * Bian(i,2) -a*b * Bian(i,1) - b*c)/(a*a+b*b);
end

for i =1:length(chuizu)
    DDD(i) = sqrt((chuizu(i,1) - Bian(length(Bian),1)).^2 +  (chuizu(i,2) - Bian(length(Bian),2)).^2);
end

for i =1:length(Bian)
    for j =1:length(Bian)
        if DDD(j)>DDD(i)  
            H(i,j) = 0;
        end
    end
end
H(1,length(Bian)) = 0;

end





