
function [node,keynode,keynodeID,notkeynode] = Keynode0613(node,N,WG,X,Y)  
%% tnmax 
for n = 1:N
    for j = 1:length(WG(n).node)
        WG(n).node(j).J_twoNe_num = length(node(WG(n).node(j).ID).J_twoNe); 
    end
end
for n = 1:N
    AAA = [0];
    t=1;
    for j=1:length(WG(n).node)
        AAA(t) = WG(n).node(j).J_twoNe_num;
        t=t+1;
    end
    WG(n).tnmax = max(AAA);
    clear AAA
end
%% 连通度LT  
for i = 1:length(node)
    node(i).LT = length(node(i).J_oneNe) + ( length( node(i).J_twoNe) / ( WG(node(i).WGID).tnmax + 1));
end   
for n = 1:N
    for j = 1:length(WG(n).node)
        WG(n).node(j).LT = node(WG(n).node(j).ID).LT; 
    end
end  
%% dmax
for n = 1:N
    for j = 1:length(WG(n).node)
        WG(n).node(j).J_one_PJdis = node(WG(n).node(j).ID).J_one_PJdis; 
    end
end

for n = 1:N
    AAA = [0];
    t=1;
    for j=1:length(WG(n).node)
        AAA(t) = WG(n).node(j).J_one_PJdis;
        t=t+1;
    end
    WG(n).dmax = max(AAA);
    clear AAA
end
%% 相邻度XL
for i = 1:length(node)
    if node(i).J_one_PJdis ~= 0
        node(i).XL =   WG(node(i).WGID).dmax / node(i).J_one_PJdis;
    else node(i).XL = 0;
    end
end  
for n = 1:N
    for j = 1:length(WG(n).node)
        WG(n).node(j).XL = node(WG(n).node(j).ID).XL; 
    end
end  
%% 
w1 = 0.7;
w2 = 0.3;
for i = 1:length(node)
    node(i).SV = (w1 * node(i).LT +w2 * node(i).XL)*node(i).Tcom;
end
for n = 1:N
    for j = 1:length(WG(n).node)
        WG(n).node(j).SV = node(WG(n).node(j).ID).SV; 
    end
end
%%
for i = 1:length(node)
    node(i).Keynode = 0;
end
for n = 1:N
    if length(WG(n).node)~= 0
        t=1;
        for j = 1:length(WG(n).node)
            AAA(t,1) = WG(n).node(j).ID;
            AAA(t,2) = WG(n).node(j).SV;
            t=t+1;
        end
        [maxA,col] = max(AAA(:,2));
        geshu = length(find(AAA(:,2) == maxA)); % 最大值有几个
        if geshu ~= 1                           % 即如果sv的最大值有相同的
            xuhao = find(AAA(:,2) == maxA);
            t = 1;
            for i = 1:length(xuhao)
                ddd(t,1) = node(AAA(xuhao(i),1)).x;
                ddd(t,2) = node(AAA(xuhao(i),1)).y;
                ddd(t,3) = node(AAA(xuhao(i),1)).ID;
                ddd(t,4) = sqrt(ddd(t,1).^2 + ddd(t,2).^2); % 和数据中心的距离
                t= t+1;
            end
           [minddd,xh] =  min(ddd(:,4));
           WG(n).KeynodeID = ddd(xh,3);
           node(ddd(xh,3)).Keynode = 1;
        else
            WG(n).KeynodeID = AAA(col,1);
            node(AAA(col,1)).Keynode = 1;
        end
    end
    clear AAA

end


%% 绘图 （标出关键节点）
% figure
% hold on 
% %%%%%% 
% set(gcf,'position',[360,55,720,720]);  %[左边距，下边距，图窗高，图窗宽]
% for i = 1:length(node)
%     pt = scatter(node(i).x,node(i).y);
%     pt.Marker = 'o';
%     pt.MarkerFaceColor = '0.9333    0.8353    0.7176';     
%     pt.MarkerEdgeColor = '0.9333    0.8353    0.7176';
%     pt.SizeData  = 10;
% %     text(node(i).x,node(i).y,num2str(node(i).ID),'FontSize',8,'HorizontalAlignment','center','VerticalAlignment','top', 'Color','black');
%                                                      
% end
% s = scatter(0,0,'filled');
% s.Marker = 'pentagram';
% s.MarkerFaceColor = 'red';
% s.SizeData  = 90;
% 
% plot(X, Y, ':k', X', Y', ':k');
% 
% % for i=1: N
% % %     plot(WG(i).x,WG(i).y,"r+")
% %     text(WG(i).x,WG(i).y,num2str(WG(i).ID),'FontSize',10,'HorizontalAlignment','center','Color','red'); %'FontSize':字体大小 HorizontalAlignment:文字相对点的位置
% % end
% axis([-320 320 -320 320]);            
% %%%
% for i = 1:length(node)
%     if node(i).Keynode ==1
%         s = scatter(node(i).x,node(i).y,'filled');
%         s.Marker = '^';
%         s.MarkerFaceColor = 'red';
%         s.MarkerFaceAlpha = 0.7;  
%         s.SizeData  = 40;
%         text(node(i).x,node(i).y,num2str(node(i).ID),'FontSize',8,'HorizontalAlignment','center','VerticalAlignment','top', 'Color','black'); 
%     end
% end

%% 
keynode(1,1) = 0;
keynode(1,2) = 0;
t = 2;
for i = 1:length(node)
    if node(i).Keynode == 1
        keynode(t,1) = node(i).x;
        keynode(t,2) = node(i).y;
        t = t+1;
    end
end
t = 2;
for i = 1:length(node)
    if node(i).Keynode == 1
        keynodeID(t,1) = node(i).x;
        keynodeID(t,2) = node(i).y;
        keynodeID(t,3) = node(i).ID;
        t = t+1;
    end
end
t = 1;
for i = 1:length(node)
    if node(i).Keynode == 0
        notkeynode(t,1) = node(i).x;
        notkeynode(t,2) = node(i).y;
        notkeynode(t,3) = node(i).ID;
        t = t+1;
    end
end
end
