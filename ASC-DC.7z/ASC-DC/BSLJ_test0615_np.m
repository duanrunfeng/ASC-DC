function [BSnode,LJ_best_long] = BSLJ_test0615_np (Bian,BianID,node)                 

BianIDvalue = [];
BianIDvalue = BianID;
for i =1:length(BianID(:,1))
    if BianID(i,3)~=0
        BianIDvalue(i,4) = node(BianID(i,3)).CJ_value; 
    end
end
M = length(Bian)*2;     
NC_max = 100;           
Alpha = 2;             
Beta = 6;              
p = 0.5;                
Q = 10;                 
Map_Size = size(Bian,1);
Start_point = 1;                    
End_point = length(Bian);           
H = Allow_table(Bian);            
N = size(H,1);                      
XXS = ones(N,N);                   
for i=1:N
    for j=1:N
        distance(i,j) = sqrt(sum((Bian(i,:)-Bian(j,:)).^2)); 
    end
end
Eta = 1 ./distance;       
per_g_ant_path = cell(NC_max,M);          
per_g_perant_pathlong = zeros(NC_max,M);   
per_g_ant_XJ = zeros(NC_max,M);            
best_gen = 1; best_m = 1;   
best_pingjia = 0;  
%% 开始迭代
for gen=1:NC_max
    for m=1:M
        S1 = Start_point;               
        Path_m = Start_point;		 
        LJ_length = 0;                
        Jingji_table = ones(1,N);      
        Jingji_table(Start_point) = 0;	
        H1 = H;                         
        H2 = H1(S1,:);         
        H3 = find(H2);          
        for j = 1:length( H3 ) 
            if Jingji_table( H3(j) ) == 0 
                H2( H3(j) ) = 0;          
            end
        end
        AllowNode = find( H2 );             
        AllowNode_num = length(AllowNode);      
        while S1 ~= End_point && AllowNode_num >= 1 	
            PP=zeros(1,AllowNode_num);   
            for i=1:AllowNode_num
                PP(i)=(XXS(S1,AllowNode(i))^Alpha)*((Eta(S1,AllowNode(i)))^Beta); 
            end
            PP = PP/sum(PP);  
            Pcum = cumsum(PP);                 
            Select = find(Pcum>=rand);       
            to_visit = AllowNode(Select(1)); 
            Path_m = [Path_m,to_visit];   
            LJ_length = LJ_length + distance(S1,to_visit);  
            S1 = to_visit;   
            for kk = 1:N
                if Jingji_table(kk) == 0    
                    H1(S1,kk) = 0;          
                    H1(kk,S1) = 0;
                end
            end
            Jingji_table(S1) = 0;   
            H2 = H1(S1,:);         
            H3 = find(H2);          
            for j = 1:length(H3)    
                if Jingji_table(H3(j)) == 0
                    H2(j) = 0;
                end
            end
            AllowNode = find(H2);              
            AllowNode_num = length(AllowNode);  
        end  
        per_g_ant_path{gen,m} = Path_m;	
        
        if Path_m(end) == End_point     
            per_g_perant_pathlong(gen,m) = LJ_length ;                       
            per_g_ant_Extralong(gen,m) = LJ_length - distance(1,End_point);  
            BianIDvalue_zan = [];
            tttt = 1;
            for xxx = 1:length(Path_m)
                BianIDvalue_zan(tttt) = BianIDvalue(Path_m(xxx),4);
                tttt=tttt+1;
            end
            XJJJJJ = (sum(BianIDvalue_zan)-2)/LJ_length; 
            per_g_ant_XJ(gen,m) = XJJJJJ;
            pingjia = 0.1 * 10/per_g_perant_pathlong(gen,m) +0.9* XJJJJJ - 0.0001*per_g_ant_Extralong(gen,m);
                        
            if pingjia > best_pingjia  
                best_pingjia = pingjia;
                best_gen = gen;
                best_m = m;
            end
        else
            per_g_ant_XJ(gen,m) = 0;
        end
    end
    Delta_XXS = zeros(N,N);
    for m = 1:M
        if per_g_ant_XJ(gen,m)~=0 
            R_zan = per_g_ant_path{gen,m};   
            TS = length(R_zan)-1;            
            PL_xj = per_g_ant_XJ(gen,m);   
            PL_num = per_g_ant_XJ(gen,m)*per_g_perant_pathlong(gen,m);
            PL_xj2 = PL_num / per_g_ant_Extralong(gen,m);
            PL_d = per_g_perant_pathlong(gen,m); 
            for s = 1:TS
                x = R_zan(s);
                y = R_zan(s+1);
                Delta_XXS(x,y) = Delta_XXS(x,y) + ( 10 / PL_d + PL_xj) ;
                Delta_XXS(y,x) = Delta_XXS(y,x) + ( 10 / PL_d + PL_xj);
            end
        end
    end
    XXS = (1-p).*XXS + Delta_XXS; 
end

LJ_best = per_g_ant_path{best_gen,best_m}; 
LJ_best_long = per_g_perant_pathlong(best_gen,best_m);  
BS = LJ_best;
BS(1) = [];BS(end)=[];
for i =1:length(BS)
   BSnode(1,i) = BianID(BS(i),3);
end





