%% 输入TSP的路径，输出该路径的邻边节点

function [TSPLBnodeID] = TSPLBnodeID_Calculate(TSPnode) 
LBnode = evalin('base', 'LBnode');
t = 1;
for i=1:length(LBnode)
    LBjuzhen(t,1) = LBnode(i).IDi;
    LBjuzhen(t,2) = LBnode(i).IDj;
    t = t+1;
end 
TSPLBnodeID_zan = [];
AAA = [];
    for i = 1:length(TSPnode)-1
        xuhao = find(LBjuzhen(:,1) == TSPnode(1,i) & LBjuzhen(:,2) == TSPnode(1,i+1) );
        for n = 1:length(LBnode(xuhao).LBnodeID)
            AAA(1,n) = LBnode(xuhao).LBnodeID(n);
        end
        TSPLBnodeID_zan = [TSPLBnodeID_zan,AAA];
    end
TSPLBnodeID = unique(TSPLBnodeID_zan);


