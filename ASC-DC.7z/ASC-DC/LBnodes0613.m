%% 邻边节点
function [LBnode,LBnodenum] = LBnodes0613(node,keynodeID,notkeynode,ccc)  
%% 
zan = [];
for j = 1:length(keynodeID)
    for i = 1:length(keynodeID)
        AAA(i,1) = keynodeID(j,3);
    end
    for i = 1:length(keynodeID)
        AAA(i,2) = keynodeID(i,3);
    end
    for t = 1:length(AAA) 
        if AAA(t,1)== AAA(t,2)
            AAA(t,:) = [];
            break;
        end
    end
    zan = [zan; AAA];
end
clear AAA
for i = 1:length(zan)
    Bian(i).IDi = zan(i,1);
    Bian(i).IDj = zan(i,2);
end
clear zan
for i =1 : length(Bian)
    if Bian(i).IDi ~= 0
        Bian(i).xi = node(Bian(i).IDi).x;
        Bian(i).yi = node(Bian(i).IDi).y;
    else
        Bian(i).xi = 0;
        Bian(i).yi =0;
    end
    if Bian(i).IDj ~= 0
        Bian(i).xj = node(Bian(i).IDj).x;
        Bian(i).yj = node(Bian(i).IDj).y;
    else
        Bian(i).xj =0;
        Bian(i).yj =0;
    end
end
for i =1 : length(Bian)
    Bian(i).LBnodeID = [];
    Bian(i).LBnodeNum = 0;
end
%% 计算每条边的邻边节点
for i = 1:length(Bian)
    Bian(i).kij = (Bian(i).yj - Bian(i).yi) / (Bian(i).xj - Bian(i).xi);
    Bian(i).bij = Bian(i).yi - Bian(i).kij*Bian(i).xi;
    Bian(i).dij = sqrt((Bian(i).xi-Bian(i).xj)*(Bian(i).xi-Bian(i).xj) + (Bian(i).yi-Bian(i).yj)*(Bian(i).yi-Bian(i).yj));
    Bian(i).kac = -1 /  Bian(i).kij;
    Bian(i).kbd = -1 /  Bian(i).kij;
    Bian(i).bac = Bian(i).yi -  Bian(i).kac * Bian(i).xi;
    Bian(i).bbd = Bian(i).yj -  Bian(i).kbd * Bian(i).xj;
end
%%%%%%
for n = 1:length(Bian)
    notkeynode_zan = notkeynode;
    for i = 1: length(notkeynode_zan)    
        d1 =  abs(( Bian(n).kij * notkeynode_zan(i,1) - notkeynode_zan(i,2) + Bian(n).bij )) / sqrt( 1 + Bian(n).kij * Bian(n).kij);
        notkeynode_zan(i,4) = d1;
    end
    for i = 1: length(notkeynode_zan)
        if notkeynode_zan(i,4)>0 && notkeynode_zan(i,4) <= ccc    
            notkeynode_zan(i,5) = 1;
        end
    end
    [hang,lie] = size(notkeynode_zan);
    if lie == 5
        for i = 1: length(notkeynode_zan)
            if notkeynode_zan(i,5) == 1
                d2 = abs(( Bian(n).kac * notkeynode_zan(i,1) - notkeynode_zan(i,2) + Bian(n).bac )) / sqrt( 1 + Bian(n).kac * Bian(n).kac);
                d3 = abs(( Bian(n).kbd * notkeynode_zan(i,1) - notkeynode_zan(i,2) + Bian(n).bbd )) / sqrt( 1 + Bian(n).kbd * Bian(n).kbd);
                if( d2+d3 <= Bian(n).dij +0.01)  
                    notkeynode_zan(i,6) = 1;
                end
            end
        end
        [hang,lie] = size(notkeynode_zan);  
        if lie == 6
            for i = 1: length(notkeynode_zan)
                if notkeynode_zan(i,6) == 1
                    Bian(n).LBnodeID = [Bian(n).LBnodeID,notkeynode_zan(i,3)];
                end
            end
        end
        
    end
    clear notkeynode_zan
    Bian(n).LBnodeNum = length(Bian(n).LBnodeID);
end
for i = 1:length(Bian)
    LBnode(i).IDi = Bian(i).IDi;
    LBnode(i).IDj = Bian(i).IDj;
    LBnode(i).LBnodeNum = Bian(i).LBnodeNum;
    LBnode(i).LBnodeID = Bian(i).LBnodeID;
end
%% 
AAA = [];
for i = 1:length(LBnode)
    AAA(i,1) = LBnode(i).LBnodeNum;
end
t = 1;
for i=1:(length(LBnode)/length(keynodeID)):length(LBnode)   
    BBB(t,:) = AAA(i:i+(length(LBnode)/length(keynodeID)-1),:);   
    t = t+1;
end     
clear AAA
ccc(1,1) = 0;
LLL1 = [ccc,BBB(1,:)];  
clear ccc
LLL2 =[];
for hang = 2:length(keynodeID)
    t=1;
    for i = 1:hang-1
        ccc(1,t) = BBB(hang,i);
        t= t+1;
    end
    ccc = [ccc,0];
    for  i = hang:(length(keynodeID)-1)
        ccc = [ccc,BBB(hang,i)];
    end
    LLL2 = [LLL2;ccc]; 
    clear ccc
end
clear BBB;
LBnodenum = [LLL1;LLL2]; 

