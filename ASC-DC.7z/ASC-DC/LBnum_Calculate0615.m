%% 根据路径顺序计算每条路径的邻边节点个数和总采集价值

function [LB_CJ_value] =  LBnum_Calculate0615 (node,Route,keynodeID,LBjuzhen,LBnode)        
    t = 1;
    for i = 1:length(Route)
        AAA(1,t) = keynodeID(Route(1,i),3);
        t = t+1;
    end 
    t = 1;
    for i = 1:length(AAA)-1
        xuhao = find(LBjuzhen(:,1) == AAA(1,i) & LBjuzhen(:,2) == AAA(1,i+1) );
        for n = 1:length(LBnode(xuhao).LBnodeID)
            LBnodeIDjuzhen(t,n) = LBnode(xuhao).LBnodeID(n);
        end
        t = t+1;
    end
    xuhao = find(LBjuzhen(:,1) == AAA(1,length(AAA)) & LBjuzhen(:,2) == AAA(1,1) );
    for n = 1:length(LBnode(xuhao).LBnodeID)
        LBnodeIDjuzhen(t,n) = LBnode(xuhao).LBnodeID(n);
    end
    buchongfu = unique(LBnodeIDjuzhen); 
for i =1:length(buchongfu)
    
    if buchongfu(i,1)~=0
        buchongfu(i,2) = node(buchongfu(i,1)).CJ_value;
    end
end
LB_CJ_value = sum(buchongfu(:,2));
        

    


      
    
