function [node,H_SF] = Trust1006(cycle,node,BBBSSSnode,keynodeID,H_SF)

for i=1:length(node)
    QWB(i).nodeID = node(i).ID;
    QWB(i).Tcom = node(i).Tcom;
    QWB(i).UAVpass = 0;
end
for i=1:length(node) 
    for num=1:length(node(i).Q_oneNe)
        node(i).Q_oneNe(num).send_time = 0;
    end
end
for i=1:length(node)
    for num=1:length(node(i).Q_oneNe)
            node(i).Q_oneNe(num).send_time = randi([5 10],1,1);
    end
end
for i=1:length(node) 
    if node(i).Malicious == 1
        for num=1:length(node(i).Q_oneNe)
            node(i).Q_oneNe(num).send_time = node(i).Q_oneNe(num).send_time + randi([0 5],1,1);
        end
    end
end
for i=1:length(node)
    for num=1:length(node(i).Q_oneNe)
        if node(node(i).Q_oneNe(num).ID).Malicious == 1   
            node(i).Q_oneNe(num).send_s_time = round(node(i).Q_oneNe(num).send_time * (randi([20 70],1,1)/100));   
        else                                               
            node(i).Q_oneNe(num).send_s_time = round(node(i).Q_oneNe(num).send_time * (randi([90 100],1,1)/100));
        end
    end
end
for i=1:length(node)
    for num=1:length(node(i).Q_oneNe)
        node(i).Q_oneNe(num).send_f_time = node(i).Q_oneNe(num).send_time - node(i).Q_oneNe(num).send_s_time;
    end
end
for i=1:length(node)
    for num=1:length(node(i).Q_oneNe)
        for k=1:length( node(node(i).Q_oneNe(num).ID).Q_oneNe )
            if node(node(i).Q_oneNe(num).ID).Q_oneNe(k).ID == node(i).ID
                node(node(i).Q_oneNe(num).ID).Q_oneNe(k).re_time = node(i).Q_oneNe(num).send_s_time;
            end
        end
    end
end
%% 
for i =1:length(node)
    for num=1:length(node(i).Q_oneNe)
        H_SF(i).Q_oneNe(num).send_s_time(cycle) = node(i).Q_oneNe(num).send_s_time;
        H_SF(i).Q_oneNe(num).send_f_time(cycle) = node(i).Q_oneNe(num).send_f_time; 
    end
end
%% 
sita_s = 2;  
sita_f = 1;
for i = 1:length(node)
    for num=1:length(node(i).Q_oneNe)
        tx = length(H_SF(i).Q_oneNe(num).send_s_time);
        S_jiaquan = 0;
        F_jiaquan = 0;
        for k =1:length(H_SF(i).Q_oneNe(num).send_s_time)
            S_jiaquan = S_jiaquan + (1/(1 + sita_s * (tx-1))) * H_SF(i).Q_oneNe(num).send_s_time(k);
            F_jiaquan = F_jiaquan + (1/(1 + sita_f * (tx-1))) * H_SF(i).Q_oneNe(num).send_f_time(k);
            tx = tx-1;
        end
        H_SF(i).Q_oneNe(num).S_jiaquan = S_jiaquan;
        H_SF(i).Q_oneNe(num).F_jiaquan = F_jiaquan;
    end
end
for i=1:length(node)
    for num=1:length(node(i).Q_oneNe)
        fz =  H_SF(i).Q_oneNe(num).S_jiaquan  + 1;
        fm =  H_SF(i).Q_oneNe(num).S_jiaquan  + (H_SF(i).Q_oneNe(num).F_jiaquan / ( 2*QWB(node(i).Q_oneNe(num).ID).Tcom )) + 2;
        node(i).Q_oneNe(num).zuobian = fz/fm;
    end
end

%% 右边
gama = 1;
for i=1:length(node)
    for num=1:length(node(i).Q_oneNe)
        if  ( node(i).CJ_value ~= 1 ) && ( node(node(i).Q_oneNe(num).ID).Malicious == 1 )  
            node(i).Q_oneNe(num).youbian = gama / (gama + randi([1 3],1,1));     % randi（[a b],m,n):生成a到b之间的m行n个整数
        else
            node(i).Q_oneNe(num).youbian = 1 ; %%% gama / (gama + 0);
        end
    end
end 
for i=1:length(node)
    for num=1:length(node(i).Q_oneNe)
        node(i).Q_oneNe(num).DT = node(i).Q_oneNe(num).zuobian * node(i).Q_oneNe(num).youbian;
    end
end
%% 虚假评价
for i =1:length(node)
    if node(i).Malicious == 1
        for num = 1:length(node(i).Q_oneNe)
            if node(node(i).Q_oneNe(num).ID).Malicious == 1
                node(i).Q_oneNe(num).fake_DT = 0.8+(0.9-0.8).*rand(1,1);        % 公式  a + (b-a).*rand(N,1) 生成区间 (a,b) 内的 N 个随机数
            else
                node(i).Q_oneNe(num).fake_DT = 0.2+(0.4-0.2).*rand(1,1);
            end
        end
    end
end

%% 
for i = 1:length(node)
    node(i).DT_avr = 0;
end
for i =1:length(keynodeID)
    if keynodeID(i,3) ~=0
        QWB(keynodeID(i,3)).UAVpass = 1;
    end
end
for i = 1:length(BBBSSSnode)
    QWB(BBBSSSnode(i)).UAVpass = 1;
end

%% Dv
lanbuda = 2;
for i = 1:length(node)
    if ( QWB(node(i).ID).UAVpass == 1 ) && ( node(i).Malicious == 1 )
        node(i).Dv(cycle) = 1 / ( 1 + lanbuda * randi([1 3],1,1) ) ;     % randi（[a b],m,n):生成a到b之间的m行n个整数
    else
         node(i).Dv(cycle) = 1;
    end
end
%% 平均的直接信任
k=1;   
for i =1: length(node)
    for num=1:length(node(i).Q_oneNe)
        if node(i).Malicious == 1
            AAA(k,:) = [ node(i).ID , node(i).Q_oneNe(num).ID , node(i).Q_oneNe(num).fake_DT,node(i).Tcom ];
        else
            AAA(k,:) = [ node(i).ID , node(i).Q_oneNe(num).ID , node(i).Q_oneNe(num).DT,node(i).Tcom  ];
        end     
        k=k+1;
    end
end
for iii = 1:length(node)
    BBB = find ( AAA(:,2) == iii )'; % find：查找AAA(:,2)中等于iii的元素，返回元素的标号，没有就返回空
    if length(BBB) ~= 0
        for i = 1:length(BBB)
            CCC(i,:) = AAA(BBB(i),:);
        end
        
        DDD = [];
        dtt = 1;
        for k=1:length(CCC(:,1))
            if CCC(k,4)>=0.5
                DDD(dtt,:) = CCC(k,:);
                dtt = dtt+1;
            end
        end
        if length(DDD) ~= 0
            node(CCC(1,2)).DT_avr = mean(DDD(:,3),'all');                % M = mean(A,'all') 计算 A 的所有元素的均值。
        else
            node(CCC(1,2)).DT_avr = 0.5;
        end
    end
    clear BBB
    clear CCC
end
%% 评价偏离度
for iii = 1:length(node)
    BBB = find ( AAA(:,2) == iii )'; % find：查找AAA(:,2)中等于iii的元素，返回元素的标号，没有就返回空
    if length(BBB) ~= 0
        for i = 1:length(BBB)
            CCC(i,:) = AAA(BBB(i),:);
        end
        
        if length(CCC(:,1)) == 1  %%如果只有一个节点评价过，则偏离度为0 === 考虑是否将这种节点不计算偏离度
            for num = 1:length(node(CCC(1,1)).Q_oneNe)
                if node(CCC(1,1)).Q_oneNe(num).ID == CCC(1,2)
                    ttt = num;
                end
            end
            node(CCC(1,1)).Q_oneNe(ttt).ijPLD =  0;
        else
            for k=1:length(CCC(:,1))
                for num = 1:length(node(CCC(k,1)).Q_oneNe)
                    if node(CCC(k,1)).Q_oneNe(num).ID == CCC(k,2)
                        ttt = num;
                    end
                end
                node(CCC(k,1)).Q_oneNe(ttt).ijPLD = abs( CCC(k,3) - (sum(CCC(:,3))-CCC(k,3))/(length(CCC(:,1))-1));
            end
            
        end
    end
    clear BBB
    clear CCC
end

%% 
for i =1:length(node)
    t = 1;
    ttt1 = [];
    for num=1:length(node(i).Q_oneNe)
        ttt1(t) = node(i).Q_oneNe(num).ijPLD;
        t = t+1;
    end
    node(i).PLD = mean(ttt1);
end
clear ttt1

%% 全局信任
w1 = 0.7;
w2 = 0.3;
for i =1:length(node)
    if  length(node(i).Q_oneNe) ~= 0
        Tcom_new = (w1*node(i).DT_avr + w2*(1-node(i).PLD)) * min( mean(node(i).Dv), node(i).Dv(cycle));
        node(i).Tcom = min(Tcom_new,(0.2*node(i).Tcom)+0.8*Tcom_new);
    end
end
for i =1:length(node)
    node(i).H_Tcom (cycle) = node(i).Tcom;
end
    