%% 增采集价值
function [BSnode,LJ_best_long] = BSLJ_test0615 (Bian,BianID,node)                

BianIDvalue = [];
BianIDvalue = BianID;
for i =1:length(BianID(:,1))
    if BianID(i,3)~=0
        BianIDvalue(i,4) = node(BianID(i,3)).CJ_value; 
    end
end

M = length(Bian)*2;     % 蚂蚁个数
NC_max = 100;           % 迭代的次数
Alpha = 2;              % 信息素重要程度
Beta = 6;               % 期望启发因子重要程度
p = 0.5;                % 信息素挥发系数
Q = 10;                 % Q常量，表示蚂蚁循环一周或一个过程在经过的路径上所释放的信息素总量
Map_Size = size(Bian,1);
Start_point = 1;                    % 起点位置
End_point = length(Bian);           % 终点位置
H = Allow_table(Bian);              % 可行点矩阵H
N = size(H,1);                      % 节点数量（包括起终点）
XXS = ones(N,N);                    % XXS 信息素矩阵，初始为1
for i=1:N
    for j=1:N
        distance(i,j) = sqrt(sum((Bian(i,:)-Bian(j,:)).^2)); 
    end
end
Eta = 1 ./distance;   
per_g_ant_path = cell(NC_max,M);           % 用细胞结构存储每一代的每一只蚂蚁的爬行路线    Routes
per_g_perant_pathlong = zeros(NC_max,M);   % 用矩阵存储每一代的每一只蚂蚁的爬行路线长度  （行号代表第几次迭代，列号是蚂蚁号）  L_routes
per_g_ant_XJ = zeros(NC_max,M);            % 用矩阵存储每一代的每一只蚂蚁的爬行路线性价比
best_gen = 1; best_m = 1;   % 记录最佳路径是第几代、第几个蚂蚁
best_pingjia = 0;  

%% 开始迭代

for gen=1:NC_max
    for m=1:M
        %% 第一步：初始化参数
        S1 = Start_point;               
        Path_m = Start_point;		    
        LJ_length = 0;                  
        Jingji_table = ones(1,N);       
        Jingji_table(Start_point) = 0;	
        H1 = H;                        
        %% 第二步：搜寻蚂蚁下一步可以前往的方格
        H2 = H1(S1,:);          
        H3 = find(H2);          % ind = find(X)：找出矩阵X中的所有非零元素，并将这些元素的线性索引值（linear indices：按列）返回到向量ind中。
        for j = 1:length( H3 )  % 排除可行节点是禁忌表里的
            if Jingji_table( H3(j) ) == 0 
                H2( H3(j) ) = 0;          % 将该走过的节点的可行点矩阵值置零
            end
        end
        AllowNode = find( H2 );             % S1的可行节点
        AllowNode_num = length(AllowNode);  % 可行节点的个数
        
        
        while S1 ~= End_point && AllowNode_num >= 1 	% 觅食停止条件
           %% 轮盘赌确定蚂蚁下一步将要到达的位置
            PP=zeros(1,AllowNode_num);%初始化状态转移概率矩阵   
            for i=1:AllowNode_num
                PP(i)=(XXS(S1,AllowNode(i))^Alpha)*((Eta(S1,AllowNode(i)))^Beta); % pij的分子
            end
            PP = PP/sum(PP);   % 计算状态转移概率pij            
            Pcum = cumsum(PP);                 
            Select = find(Pcum>=rand);       
            to_visit = AllowNode(Select(1)); % 找到下一个位置点
            
            %% 更新状态并做有关记录
            Path_m = [Path_m,to_visit];  
            LJ_length = LJ_length + distance(S1,to_visit);  
            S1 = to_visit;   
            %更新禁忌表
            for kk = 1:N
                if Jingji_table(kk) == 0    % 已走过的点不能再被选
                    H1(S1,kk) = 0;          % 断开移到的下一节点与禁忌表中节点的连接
                    H1(kk,S1) = 0;
                end
            end
            Jingji_table(S1) = 0;   % 已访问过的节点从禁忌表中删除
            H2 = H1(S1,:);          % 下一节点连接的所有节点
            H3 = find(H2);          % find H2 的非零元素，返回非零元素的编号给H3
            for j = 1:length(H3)    % 在S1的可行节点中排除已经走过的节点
                if Jingji_table(H3(j)) == 0
                    H2(j) = 0;
                end
            end
            AllowNode = find(H2);               % 更新可行节点
            AllowNode_num = length(AllowNode);  % 可选节点的个数
        end
        
        %% 记录蚂蚁的爬行路线并且记录搜索到本轮最佳路径的蚂蚁及路径长度
        per_g_ant_path{gen,m} = Path_m;	% 存储第gen轮第m个蚂蚁的路线
        if Path_m(end) == End_point     
            per_g_perant_pathlong(gen,m) = LJ_length ;                       
            per_g_ant_Extralong(gen,m) = LJ_length - distance(1,End_point);             
            BianIDvalue_zan = [];
            tttt = 1;
            for xxx = 1:length(Path_m)
                BianIDvalue_zan(tttt) = BianIDvalue(Path_m(xxx),4);
                tttt=tttt+1;
            end
            XJJJJJ = (sum(BianIDvalue_zan)-2)/LJ_length;             
            per_g_ant_XJ(gen,m) = XJJJJJ; 
            pingjia = 0.1 * 10/per_g_perant_pathlong(gen,m) +0.9* XJJJJJ - 0.0001*per_g_ant_Extralong(gen,m);         
            if pingjia > best_pingjia 
                best_pingjia = pingjia;
                best_gen = gen;
                best_m = m;
            end
        else
            per_g_ant_XJ(gen,m) = 0; % 没有到达终点的话
        end
    end
    %% 信息素更新
    Delta_XXS = zeros(N,N);
    for m = 1:M
        if per_g_ant_XJ(gen,m)~=0  
            R_zan = per_g_ant_path{gen,m};   
            TS = length(R_zan)-1;            
            PL_xj = per_g_ant_XJ(gen,m);   
            PL_num = per_g_ant_XJ(gen,m)*per_g_perant_pathlong(gen,m);
            PL_xj2 = PL_num / per_g_ant_Extralong(gen,m);
            PL_d = per_g_perant_pathlong(gen,m); 
            for s = 1:TS
                x = R_zan(s);
                y = R_zan(s+1);
                Delta_XXS(x,y) = Delta_XXS(x,y) + ( 10 / PL_d + PL_xj) ;
                Delta_XXS(y,x) = Delta_XXS(y,x) + ( 10 / PL_d + PL_xj);
            end
        end
    end
    XXS = (1-p).*XXS + Delta_XXS; 
end



%% 绘图
% % 绘制寻优路径收敛曲线
% minrt=zeros(NC_max);
% rt11=zeros(1,M);
% for i=1:NC_max
%     rt11=per_g_perant_pathlong(i,:);
%     Nzero=find(rt11);
%     rt12=rt11(Nzero);
%     minrt(i)=min(rt12);
% end
% figure
% plot(minrt);
% hold on
% grid on
% title('机器人寻优路径收敛曲线');
% xlabel('迭代的次数');
% ylabel('蚂蚁搜寻路径长度');

% 绘蚂蚁爬行图
% figure
hold on
% grid on                                % 显示或隐藏坐标区网格线
% axis ('padded','equal')                % padded:边距的宽度为数据范围的7%   % equal：坐标轴使用相同的数据单位长度
axis([-320 320 -320 320]);             %设置显示范围。
set(gcf,'position',[360,55,720,720]);  % 设置图窗大小,窗口大小[左边距，下边距，图窗高，图窗宽]
LJ_best = per_g_ant_path{best_gen,best_m}; % 最佳路径
LJ_best_long = per_g_perant_pathlong(best_gen,best_m);  % 最佳路径长度

%%% ***底图
% for i = 1:length(Bian) 
%     s1 = scatter(Bian(i,1),Bian(i,2));
%     s1.MarkerFaceColor = 'b';
%     s1.MarkerEdgeColor = 'b';
%     s1.MarkerFaceAlpha = 0.45;  
%     s1.MarkerEdgeAlpha = 0.2;  
%     s1.SizeData  = 13;
% %     text(Bian(i,1),Bian(i,2),num2str((i)),'FontSize',9,'HorizontalAlignment','center','VerticalAlignment','cap', 'Color','black'); %text - 向数据点添加文本描述  num2str - 将数字转换为字符数组
% end
% 
% plot([Bian(1,1),Bian(end,1)],[Bian(1,2),Bian(end,2)],'-.b');
% 
% L1 = line([Bian(1,1),Bian(end,1)],[Bian(1,2),Bian(end,2)]);
% L1.Color =[0,0,1,0.5];  
% L1.LineStyle ='-.';

for i=1:length(LJ_best)-1   
    ax = [Bian(LJ_best(i),1),Bian(LJ_best(i+1),1)];
    ay = [Bian(LJ_best(i),2),Bian(LJ_best(i+1),2)];
    h1 = plot(ax,ay,'-.r');
    h1.LineWidth = 1.2;
    hold on
end

 %******绘制起点和终点图标
 s2 = scatter([Bian(1,1),Bian(end,1)],[Bian(1,2),Bian(end,2)]);
 s2.Marker = '^';
 s2.SizeData = 34;
 s2.LineWidth = 0.5;
 s2.MarkerFaceAlpha = 0.7;  % 透明度
 s2.MarkerEdgeColor = '0.0824    0.5922    0.6471';     % 灰绿
 s2.MarkerFaceColor = '0.0824    0.5922    0.6471';
 

%******绘制伴随节点图标
BS = LJ_best;
BS(1) = [];BS(end)=[];
for i = 1:length(BS)
    ax2 = Bian(BS(i),1);
    ay2 = Bian(BS(i),2);
    h2 = scatter(ax2,ay2);
    h2.Marker = 'square';
    h2.SizeData = 36.5;  
    h2.LineWidth = 0.99;
%     h2.MarkerFaceColor = 'y';
%     h2.MarkerEdgeColor ='r';
    h2.MarkerFaceColor = '0.9882    0.9725    0.7333';
    h2.MarkerEdgeColor ='0.9843    0.5176    0.0078';

end
    

% title(['长度：',num2str(per_g_perant_pathlong(best_gen,best_m)),'   个数：' ,num2str(length(LJ_best)-2),'   XJ1：',num2str(   (length(LJ_best)-2)/ per_g_perant_pathlong(best_gen,best_m)   )],...
%     ['额外长度：',num2str(per_g_ant_Extralong(best_gen,best_m))  ,'           XJ2：',num2str(   (length(LJ_best)-2)/ (per_g_perant_pathlong(best_gen,best_m) - distance(1,End_point))   )         ] );


%% 将伴随节点转为节点编号后存储

for i =1:length(BS)
   BSnode(1,i) = BianID(BS(i),3);
end





