%% 计算识别率
function [R_rate] = R_rateee(node,Proportion)
Mali_num = length(node)*Proportion;
k=1;
for i =1: length(node)
    MMM(k,:) = [ node(i).ID , node(i).Malicious , node(i).Tcom ];
    k=k+1;
end
MMM2 = sortrows(MMM,3);   
for i = 1:Mali_num
    MMM3(i,:) = MMM2(i,:);
end
shibie_num = length(find(  MMM3(:,2)==1   ));
R_rate = shibie_num / Mali_num
clear MMM    
clear MMM2    
clear MMM3    