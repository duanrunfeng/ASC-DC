clear all;
close all;
clc;

%% 节点信息
node_x = [];
node_y = [];
n=1;  % 控制结构体node 的序号
fid = fopen('D:\codemat\network500.txt','rt');
while ~feof(fid)
    node(n).ID = n;            % 用结构体node存放每个节点的ID
    line1 = fgetl(fid);      % fgetl读取文件中的行，并删除换行符
    line2 = fgetl(fid);
    ps = regexp(line1,'=');  % regexp匹配正则表达式（区分大小写）%找等于号在line1的几处开始
    ps = ps +1;
    str1 = line1(ps:end);    % 从ps位置到结尾的字符串赋给str1
    str2 = line2(ps:end);
    x = str2num(str1);       % str2num - 将字符数组或字符串转换为数值数组
    y = str2num(str2);
    node_x = [node_x,x];     % 循环更新一维数组node_x，新元素内容放后面
    node_y = [node_y,y];
    node(n).x=node_x(n);     % 用结构体node存放每个节点的x坐标   node(1).x   node(2).x   node(3).x  node(4).x  ......
    node(n).y=node_y(n);     % 用结构体node存放每个节点的y坐标   node(1).y   node(2).y   node(3).y  node(4).y  ......
    node(n).WGID = [];
    node(n).Tcom =0.5;
    node(n).H_Tcom =[];
    node(n).CJ_value = 1;    % 采集价值
    node(n).Dv = 1;
    n=n+1;
end



%% 参数
Proportion = 0.3;       % 恶意节点的占比
ccc = 25;               % 邻边节点范围宽度：文中的c


%% 随机生成x%的恶意节点

for i=1:length(node)
    node(i).Malicious=0;
end
R=randperm(length(node),length(node)*Proportion);    
for i=1:length(R(:))
    node(R(i)).Malicious=1;
end 

%% 划分网格
WangGe0613

%% 计算邻居信息
Neighbor0417

%% 邻居的恶意信息
for i =1:length(node)
    for num = 1:length(node(i).Q_oneNe)
        node(i).Q_oneNe(num).Malicious = node(node(i).Q_oneNe(num).ID).Malicious;
    end
end


%% 用于记录历史成功和失败交互的H_SF
for i = 1:length(node)
    H_SF(i).ID  = node(i).ID;
    H_SF(i).Q_oneNe = node(i).Q_oneNe;
end

%% ****************************************
for cycle = 1:50
%% CH
[node,keynode,keynodeID,notkeynode] = Keynode0613(node,N,WG,X,Y);
%% AE-node
LBnode = LBnodes0613(node,keynodeID,notkeynode,ccc);
%% TSPLJ
% [QQQR,QQQR_zz] = TSPLJ0613(X,Y,node,keynodeID,keynode,LBnode);  % 绘图
[QQQR,QQQR_zz] = TSPLJ0613_np(X,Y,node,keynodeID,keynode,LBnode); % 不绘图
pause(0.001);
%% 抽查路径
BBBSSSnode=[];
%  BBBSSSnode = BSLJ0613(QQQR_zz,keynodeID,node,X,Y);  % 带绘图 
 BBBSSSnode = BSLJ0613_np(QQQR_zz,keynodeID,node,X,Y);  % 不带绘图 
%% 更新信任值
[node,H_SF] = Trust1006(cycle,node,BBBSSSnode,keynodeID,H_SF);
% 计算识别率
R_rate(cycle) = R_rateee(node,Proportion);
%% 更新节点的采集价值
jian = 0.5;
for i = 1:length(BBBSSSnode)
    node(BBBSSSnode(i)).CJ_value = node(BBBSSSnode(i)).CJ_value - jian; 
end
for i = 1:length(node)
    if node(i).CJ_value <= 0
        node(i).CJ_value = 0.001;
    end
end
%%% 重置
if cycle == 5
    for i = 1:length(node)
        if  node(i).CJ_value~=1
            node(i).CJ_value = 0.999 ;
        end
    end
end

%% 查看UAV覆盖率
UAV_fg = 0;
for i=1:length(node)
    if node(i).CJ_value ~=1
        UAV_fg = UAV_fg + 1;
    end
end
UAV(cycle,1) = length(BBBSSSnode);
UAV(cycle,2) = UAV_fg;

end