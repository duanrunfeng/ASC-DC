function [FrontNO] = FPX5(L,XJ)     
Obj_data(:,1) = L;
Obj_data(:,2) = 0.1./XJ;
[FrontNO,MaxFNO] = NDSort(Obj_data,length(Obj_data));   
function [FrontNO,MaxFNO] = NDSort(Obj_data,nSort)    
    [N,M] = size(Obj_data);
    FrontNO = inf(1,N);
    MaxFNO  = 0;
    [Obj_data,rank] = sortrows(Obj_data);
    while sum(FrontNO<inf) < min(nSort,N)
        MaxFNO = MaxFNO + 1;
        for i = 1 : N
            if FrontNO(i) == inf
                Dominated = false;
                for j = i-1 : -1 : 1
                    if FrontNO(j) == MaxFNO
                        m = 2;
                        while m <= M && Obj_data(i,m) >= Obj_data(j,m)
                            m = m + 1;
                        end
                        Dominated = m > M;
                        if Dominated || M == 2
                            break;
                        end
                    end
                end
                if ~Dominated
                    FrontNO(i) = MaxFNO;
                end
            end
        end
    end
    FrontNO(rank) = FrontNO;
end
end