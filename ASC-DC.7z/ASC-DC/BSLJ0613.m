function [Best_BSLJ_node_ID] = BSLJ0613(QQQR_zz,keynodeID,node,X,Y)
TSP_LJ = QQQR_zz;
for j =1:length(TSP_LJ(:,1))
    t = 1;
    for i = 1:length(TSP_LJ)
        LLLJJJ(j,t) = keynodeID(TSP_LJ(j,i),3);
        t = t+1;
    end 
end
Z_TSPnode = [];
for j = 1: length(TSP_LJ(:,1))
    TSPnode = [];
    BBB = [];
    AAA = [];
    AAA = LLLJJJ(j,:);
TSPnode(1,1) = 0;       
if find(AAA == 0)~=1 && find(AAA == 0)~=length(AAA)
    Ci = find(AAA == 0)+1;
    Cj = find(AAA == 0)-1;
    dis_i = sqrt(node(AAA(Ci)).x.^2 + node(AAA(Ci)).y.^2);%Ci与数据中心的距离
    dis_j = sqrt(node(AAA(Cj)).x.^2 + node(AAA(Cj)).y.^2);%Ci与数据中心的距离
    if dis_i <= dis_j 
        for i = 1:Cj
            BBB(i) = AAA(i);
        end
        t = 2;
        for i = Ci:length(AAA)
            TSPnode(t) = AAA(i);
            t = t+1;
        end
        TSPnode = [TSPnode,BBB];
    end
    if dis_i > dis_j    
        AAA = fliplr(AAA); 
        Ci = find(AAA == 0)+1;
        Cj = find(AAA == 0)-1;
        for i = 1:Cj
            BBB(i) = AAA(i);
        end
        t = 2;
        for i = Ci:length(AAA)
            TSPnode(t) = AAA(i);
            t = t+1;
        end
        TSPnode = [TSPnode,BBB];
    end
end
if find(AAA == 0)==1         
    TSPnode = AAA;
end
if find(AAA == 0)==length(AAA)  
    TSPnode = fliplr(AAA);
end
TSPnode = [TSPnode,0];  
Z_TSPnode = [Z_TSPnode;TSPnode];
end
clear AAA;clear BBB
clear TSPnode
Z_TSPnode = unique(Z_TSPnode, 'rows');   

for i=1:length(node)
    node(i).BSelse = 0;
end



%% 绘图

for n = 1:length(Z_TSPnode(:,1))
    figure
    hold on
    axis([-320 320 -320 320]);  
    set(gcf,'position',[360,55,720,720]);  % [左边距，下边距，图窗高，图窗宽]  
    TSPnode = Z_TSPnode(n,:); 
    TSPLBnode = [];
    TSPLBnode = TSPLBnodeID_Calculate(TSPnode); % 该条路径下的邻边节点
%% ******绘制节点分布图
title('节点分布'); 
for i = 1:length(node)
    pt = scatter(node(i).x,node(i).y);
    pt.Marker = 'o';
    pt.MarkerFaceColor = '0.9333    0.8353    0.7176';     
    pt.MarkerEdgeColor = '0.9333    0.8353    0.7176';
    pt.SizeData  = 10;
end
%% ******绘制网格
pause(2);     
plot(X, Y, ':k', X', Y', ':k');
pause(0.5);
for i = 1:length(keynodeID)
    gj = scatter(keynodeID(i,1),keynodeID(i,2));
    gj.Marker = '^';
    gj.SizeData = 34;
    gj.LineWidth = 0.5;
    gj.MarkerFaceAlpha = 1;  % 透明度
    gj.MarkerEdgeColor = '0.0824    0.5922    0.6471';     % 灰绿
    gj.MarkerFaceColor = '0.0824    0.5922    0.6471';
end
pause(1);
plot([0,node(TSPnode(2)).x],[0,node(TSPnode(2)).y],'-.','Color','0,0,1,0.5');
for i =2:length(TSPnode)-2
    plot(  [ node(TSPnode(i)).x,node(TSPnode(i+1)).x ] ,  [ node(TSPnode(i)).y,node(TSPnode(i+1)).y ],'-.','Color','0,0,1,0.5'  );
end
plot(  [node(TSPnode(end-1)).x,0],[node(TSPnode(end-1)).y,0],  '-.' ,'Color','0,0,1,0.5' );
pause(0.001);
for i =1:length(TSPLBnode)
    lb = scatter( node(TSPLBnode(i)).x,node(TSPLBnode(i)).y );
    lb.Marker = 'o';
    lb.MarkerFaceColor = '0.4510    0.7294    0.8392';
    lb.MarkerEdgeColor = '0.4510    0.7294    0.8392';
    lb.SizeData  = 10;
end
pause(1);
BSnode_zan = [];
BSLJ_long = 0;
for i = 1:length(TSPnode)-1
    Start = TSPnode(i);
    End = TSPnode(i+1);
    [Bian,BianID] = SE_Bian(Start,End); 
    Bian_2 = [];
    BianID_2 = [];
    for s1 = 1:length(BianID(:,1))
        if BianID(s1,3)~=0
            BianID(s1,4) = node(BianID(s1,3)).BSelse;
            
        else  BianID(s1,4) = 0;
        end
    end
    t1=1;
    for s1 = 1:length(BianID(:,1))
        if BianID(s1,4) == 0
            BianID_2(t1,:) = BianID(s1,:);
            t1 = t1+1;
        end
    end
    Bian_2(:,1)=  BianID_2(:,1);
    Bian_2(:,2)=  BianID_2(:,2);     
    if length(Bian_2)~= 2   % 只有起点和终点的（没有邻边节点）的边不进入伴随路径规划        
        [AAA,BBB] = BSLJ_test0615(Bian_2,BianID_2,node);
        BSnode_zan = [BSnode_zan,AAA];
        BSLJ_long = BSLJ_long+BBB;       
        for s2 = 1:length(AAA)
            node(AAA(s2)).BSelse = 1;
        end        
        clear AAA
        pause(0.0001);        
    else 
        BSLJ_long = BSLJ_long + sqrt((BianID_2(end,1)- BianID_2(1,1))^2+ (BianID_2(end,2)- BianID_2(1,2))^2);        
    end
end
BSnode = unique(BSnode_zan); 
pause(0.0001);    % pause(n)：暂停执行n秒，然后继续执行。
    zx = scatter(0,0,'filled');          % 中心
    zx.Marker = 'pentagram';
    zx.MarkerFaceColor = 'red';
    zx.SizeData  = 100;
pause(0.0001);
BSLJPJ (n,1) = BSLJ_long;                       
BSLJPJ (n,2) = length(BSnode);                  
BSLJPJ (n,3) = 100*(length(BSnode)/BSLJ_long); 
BSnodejiegou(n).BSnode = BSnode;

end
max_value = max(BSLJPJ (:,3) );
zuiyou_hang = find( max_value == BSLJPJ (:,3));
Best_BSLJ = Z_TSPnode(zuiyou_hang,:);
Best_BSLJ_node_ID = BSnodejiegou(zuiyou_hang).BSnode;
