%% 
distance=zeros(length(node));
for i= 1:length(node)
    for j= 1:length(node)
        x1=node(i).x;
        y1=node(i).y;
        x2=node(j).x;
        y2=node(j).y;
        x=x1-x2;
        y=y1-y2;
        distance(i,j) = sqrt(x*x+y*y);
    end
end
%% 全局一跳邻居
for i=1:length(node)
    t = 1;
    for j=1:length(node)
        if distance(i,j) <= R && distance(i,j)>0      
            node(i).Q_oneNe(t).ID = j;
            node(i).Q_oneNe(t).dis = distance(i,j);
            t = t+1;
        end
    end
end
for i=1:length(node)
    node(i).Q_oneNe_num = length(node(i).Q_oneNe);
end
for i=1:length(node)
    sumd = 0;
    for j = 1:length(node(i).Q_oneNe)
        sumd = sumd + node(i).Q_oneNe(j).dis;
    end
    node(i).Q_one_PJdis = sumd / node(i).Q_oneNe_num;
    if node(i).Q_oneNe_num == 0
         node(i).Q_one_PJdis = 0;
    end
end
%% 集群内的一跳邻居
for i = 1:length(node)
    t = 1;
    for j = 1:length(node)
        if distance(i,j) <= R && distance(i,j)>0   && node(i).WGID == node(j).WGID   % 改：一跳邻居是集群内的
            node(i).J_oneNe(t).ID = j;
            node(i).J_oneNe(t).dis = distance(i,j);
            t = t+1;
        end
    end
end
for i = 1:length(node)
    node(i).J_oneNe_num = length(node(i).J_oneNe);
end
for i=1:length(node)
    sumd = 0;
    for j = 1:length(node(i).J_oneNe)
        sumd = sumd + node(i).J_oneNe(j).dis;
    end
    node(i).J_one_PJdis = sumd / node(i).J_oneNe_num;
    if node(i).J_oneNe_num == 0
         node(i).J_one_PJdis = 0;
    end
end
%% 两跳邻居 - 全局一跳下的两跳
for i=1:length(node)   
    twoID = [0];
    if node(i).Q_oneNe_num ~= 0        
    m = 1;
    for j = 1:length(node(i).Q_oneNe)
        n = 1;
        for k = 1:length(node(node(i).Q_oneNe(j).ID).Q_oneNe)
            AAA(m,n) = node(node(i).Q_oneNe(j).ID).Q_oneNe(k).ID;  
            n = n+1;
        end
        m = m+1;
    end
    if length(node(i).Q_oneNe) == 1
        BBB = unique(AAA);     
    else
        BBB = unique(AAA)';
    end
    m = 1;
    for j=1:length(node(i).Q_oneNe)
        CCC(m) = node(i).Q_oneNe(j).ID;
        m = m+1;
    end
    DDD = [BBB,CCC,CCC];       
    KKK = tabulate(DDD(:));      
    q = 1;
    for v=1:length(KKK(:,2))
        if KKK(v,2) == 1
            QQQ(q) = KKK(v,1);    
            q = q+1;
        end
    end
    t = 1;
    for u =1 :length(QQQ)
        if (QQQ(u) ~= i && QQQ(u)~=0)
            twoID(t) = QQQ(u);
            t = t+1;
        end
    end
    g = 1;
    for r=1:length(twoID)
        if twoID(r) ~= 0
            node(i).Q_twoNe(g).ID = twoID(r);
            node(i).Q_twoNe(g).dis = distance(i,node(i).Q_twoNe(g).ID);
            g = g+1;
        end
    end
    clear AAA
    clear BBB
    clear CCC
    clear DDD
    clear KKK
    clear QQQ
    clear twoID
    end
end
%% 两跳邻居 - 集群一跳下的两跳

for i=1:length(node)   
    twoID = [0];
    if node(i).J_oneNe_num ~= 0        
    m=1;
    for j = 1:length(node(i).J_oneNe)
        n=1;
        for k = 1:length(node(node(i).J_oneNe(j).ID).J_oneNe)
            AAA(m,n) = node(node(i).J_oneNe(j).ID).J_oneNe(k).ID;  
            n = n+1;
        end
        m = m+1;
    end    
    if length(node(i).J_oneNe) == 1
        BBB = unique(AAA);     
    else
        BBB = unique(AAA)';
    end
    m = 1;
    for j=1:length(node(i).J_oneNe)
        CCC(m)= node(i).J_oneNe(j).ID;
        m = m+1;
    end    
    DDD = [BBB,CCC,CCC];       
    KKK = tabulate(DDD(:));       
    q = 1;
    for v=1:length(KKK(:,2))
        if KKK(v,2) == 1
            QQQ(q) = KKK(v,1);    
            q = q+1;
        end
    end    
    t = 1;
    for u =1 :length(QQQ)
        if (QQQ(u)~= i && QQQ(u)~=0)
            twoID(t) = QQQ(u);
            t = t+1;
        end
    end
    g = 1;
    for r=1:length(twoID)
        if twoID(r)~=0
            node(i).J_twoNe(g).ID = twoID(r);
            node(i).J_twoNe(g).dis = distance(i,node(i).J_twoNe(g).ID);
            g = g+1;
        end
    end
    clear AAA
    clear BBB
    clear CCC
    clear DDD
    clear KKK
    clear QQQ
    clear twoID
    end
end