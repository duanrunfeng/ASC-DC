K = 2;               % 允许的跳数
R = 40;              % 节点的通信半径
a = sqrt(2)*K*R;     % 网格的边长
L = 600;             % 节点分布图的边长
n = ceil(L/a);       % 虚拟网格的横纵个数
N = n*n;             % 网格数量
a = L/n;   
xmin = -300;
ymin = -300;
for i=1:n+1
     xtick(i) = -300+(i-1)*a;
     ytick(i) = -300+(i-1)*a;
end
[X,Y] = meshgrid(xtick,ytick);

%% 网格编号(网格结构体）
for i =1:n   
    idx = 1;
    WG(i).ID = i;
    WG(i).IDX = idx;
    WG(i).IDY =i;
    WG(i).x = (xmin + a/2)+(i-1)*a;
    WG(i).y = ymin + a/2;
end
for i =1 :n-1
    y=1;
    s=1;
    for k =(i*n+1):((i+1)*n)   % k为网格序号
        WG(k).ID = k;
        WG(k).IDX = i+1;
        WG(k).IDY = y;
        WG(k).x = (xmin + a/2) + (s-1)*a;
        WG(k).y = (ymin + a/2) + i*a;
        s=s+1;    
        y=y+1;
    end
end
%% 节点划分归属             
for i=1:length(node)
    A = ceil((node(i).x-(-300)) / a);
    B = ceil((node(i).y-(-300)) / a);
    if A<=n && B<=n
        node(i).WGID = (B-1)*n + A;
    end
end
for n=1:N
    num=1;
    for i=1:length(node)
        if node(i).WGID == WG(n).ID
            WG(n).node(num).ID=node(i).ID;
            num=num+1;
        end
    end
end